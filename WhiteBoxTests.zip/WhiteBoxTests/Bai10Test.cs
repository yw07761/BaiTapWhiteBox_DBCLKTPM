﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace WhiteBoxTests
{
    [TestClass]
    public class Bai10Test
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
